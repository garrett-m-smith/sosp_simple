# Self-organized sentence processing (SOSP): Simple, one-word parsing models

This is Python package for running self-organized sentence processing (SOSP; Smith, Franck, & Tabor, 2018, Cog. Sci.; Smith & Tabor, 2018, Proceedings of ICCM) simulations for human sentence processing.

This package is for running models of sentence processing at single words where the parameters are set manually.

## Tutorial
Coming soon.


## Installation

Running this at the command line should work:
```
pip install git+https://github.com/garrett-m-smith/sosp_simple
```
Let me know if it doesn't.